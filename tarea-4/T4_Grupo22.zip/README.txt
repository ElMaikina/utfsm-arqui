Nombre: Miguel Soto Delgado
Rol: 201973623-K

Nombre: Martín Arancibia Alvarado
Rol: 201973517-9

Acerca del informe:
El informe fue realizado entre ambos, en donde repartimos el trabajo
por igual, cada uno trabajo con su parte del código y en la elaboraión
y redacción del informe.

Es importante señalar que el programa necesita rellenar todos los datos, de
no ser así, el programa no se ejecutará.
